package com.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.RegisterDAO1;
import com.bean.RegisterBean1;

import java.util.*;
public class RegisterController1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public RegisterController1() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstname = request.getParameter("firstname");
		String lastname= request.getParameter("lastname");
		String age= request.getParameter("age");
		
		String gender= request.getParameter("gender");
		String b=request.getParameter("contact");
		long contact= Long.parseLong(b);
		String adminName = request.getParameter("adminid");
		String password = request.getParameter("password");



		RegisterBean1 registerBean1 = new RegisterBean1();
		registerBean1.setAdminid(adminName);
		registerBean1.setPassword(password);
		registerBean1.setAge(age);
		registerBean1.setGender(gender);
		registerBean1.setFirstname(firstname);
		registerBean1.setLastname(lastname);
		registerBean1.setContact(contact);


		RegisterDAO1 registerDAO1 = new RegisterDAO1();

		
		String userRegistered = registerDAO1.registerUser(registerBean1);
        HttpSession session=request.getSession();
		if (userRegistered.equals("SUCCESS")) {
            session.setAttribute("RegBean1",registerBean1);
System.out.println("Registration Successful.");
request.getRequestDispatcher("/login1.jsp").forward(request, response);
} else {
System.out.println("Registration not successful.");
request.getRequestDispatcher("/reg1.jsp").forward(request, response);
}

	}
	}