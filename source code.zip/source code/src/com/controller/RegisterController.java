package com.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.RegisterDAO;
import com.bean.RegisterBean;

import java.util.*;
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public RegisterController() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstname = request.getParameter("firstname");
		String lastname= request.getParameter("lastname");
		String age= request.getParameter("age");
		String gender= request.getParameter("gender");
		String b=request.getParameter("contact");
		long contact= Long.parseLong(b);
		String userName = request.getParameter("userid");
		String password = request.getParameter("password");
		String pno=request.getParameter("pno");
		String vno=request.getParameter("vno");
		


		RegisterBean registerBean = new RegisterBean();
		registerBean.setUserid(userName);
		registerBean.setPassword(password);
		registerBean.setAge(age);
		registerBean.setGender(gender);
		registerBean.setFirstname(firstname);
		registerBean.setLastname(lastname);
		registerBean.setContact(contact);
		registerBean.setPno(pno);
		registerBean.setVno(vno);

		RegisterDAO registerDAO = new RegisterDAO();

		
		String userRegistered = registerDAO.registerUser(registerBean);
        HttpSession session=request.getSession();
		if (userRegistered.equals("SUCCESS")) {
            session.setAttribute("RegBean",registerBean);

request.getRequestDispatcher("/login.jsp").forward(request, response);
} else {

request.getRequestDispatcher("/reg.jsp").forward(request, response);
}

	}
	}

































/*package register.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import register.bean.RegisterBean;
import register.DAO.RegisterDAO;

public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;


                public RegisterController() {
                }

                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



                                String userName = request.getParameter("userid");
                                String password = request.getParameter("password");
                                String firstname=request.getParameter("firstname");
                                String lastname=request.getParameter("lastname");
                                String age=request.getParameter("age");
                                String gender=request.getParameter("gender");
                                String contact=request.getParameter("contact");

                                RegisterBean registerBean = new RegisterBean(); 
                                registerBean.setUserName(userName);
                                registerBean.setPassword(password);
                                registerBean.setAge(age);
                                registerBean.setGender(gender);
                                registerBean.setFirstname(firstname);
                                registerBean.setLastname(lastname);
                                registerBean.setContact(contact);

                                if(firstname.isEmpty() || lastname.isEmpty() || userName.isEmpty() || 
                        				password.isEmpty() || age.isEmpty() || contact.isEmpty() || gender.isEmpty())
                        		{
                        			RequestDispatcher req = request.getRequestDispatcher("login.jsp");
                        			req.include(request, response);
                        		}
                        		else
                        		{
                        			RequestDispatcher req = request.getRequestDispatcher("reg.jsp");
                        			req.forward(request, response);
                        		}


                                RegisterDAO registerDao = new RegisterDAO(); 
                                String userValidate = registerDao.authenticateUser(registerBean); 
                                if(userValidate.equals("SUCCESS")) 
                                {
                                                request.setAttribute("userName", userName); 
                                                request.getRequestDispatcher("/home.jsp").forward(request, response);
                                }
                                else
                                {
                                                request.setAttribute("errMessage", userValidate); 
                                                request.getRequestDispatcher("/reg.jsp").forward(request, response);
                                }*/

