package com.controller;
import java.util.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.TripDAO;
import com.bean.TripBean;

import java.util.*;
public class TripController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public TripController() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String firstname = request.getParameter("firstname");
		String lastname= request.getParameter("lastname");
		String age= request.getParameter("age");
		
		String gender= request.getParameter("gender");
		String b=request.getParameter("contact");
		long contact= Long.parseLong(b);
		String userName = request.getParameter("userid");
		String flocation = request.getParameter("flocation");
		String tlocation = request.getParameter("tlocation");
		String flightname = request.getParameter("flightname");
		String tripdate = request.getParameter("tripdate");
		int billamount=5000;
        try {


		TripBean tripBean = new TripBean();
		tripBean.setFlightname(flightname);
		tripBean.setFlocation(flocation);
        tripBean.setTripdate(tripdate);
		tripBean.setTlocation(tlocation);
		tripBean.setGender(gender);
		tripBean.setFirstname(firstname);
		tripBean.setLastname(lastname);
		tripBean.setContact(contact);
		tripBean.setAge(age);
		tripBean.setUserid(userName);
		
 
		TripDAO tripDAO = new TripDAO();

		if(flocation=="Allahabad" && tlocation=="Bengaluru")
		{
			billamount=5000;
		}
		if(flocation=="Allahabad" && tlocation=="Bhopal")
		{
			billamount=6000;
		}
		if(flocation=="Allahabad" && tlocation=="Bhuj")
		{
			billamount=7000;
		}
		if(flocation=="Allahabad" && tlocation=="Dehradun")
		{
			billamount=15000;
		}
		if(flocation=="Allahabad" && tlocation=="Ahmedabad")
		{
			billamount=8000;
		}
		if(flocation=="Allahabad" && tlocation=="Delhi")
		{
			billamount=9000;
		}
		if(flocation=="Allahabad" && tlocation=="Diu")
		{
			billamount=7000;
		}
		if(flocation=="Allahabad" && tlocation=="Gorakhpur")
		{
			billamount=5000;
		}
		if(flocation=="Bengaluru" && tlocation=="Allahabad")
		{
			billamount=4000;
		}
		if(flocation=="Bengaluru" && tlocation=="Bhopal")
		{
			billamount=6000;
		}
		if(flocation=="Bengaluru" && tlocation=="Bhuj")
		{
			billamount=5000;
		}
		if(flocation=="Bengaluru" && tlocation=="Dehradun")
		{
			billamount=8000;
		}
		if(flocation=="Bengaluru" && tlocation=="Ahmedabad")
		{
			billamount=8000;
		}
		if(flocation=="Bengaluru" && tlocation=="Delhi")
		{
			billamount=8000;
		}
		if(flocation=="Bengaluru" && tlocation=="Diu")
		{
			billamount=9000;
		}
		if(flocation=="Bengaluru" && tlocation=="Gorakhpur")
		{
			billamount=4000;
		}
		if(flocation=="Bhopal" && tlocation=="Allahabad")
		{
			billamount=3000;
		}
		if(flocation=="Bhopal" && tlocation=="Bhuj")
		{
			billamount=4500;
		}
		if(flocation=="Bhopal" && tlocation=="Dehradun")
		{
			billamount=7000;
		}
		if(flocation=="Bhopal" && tlocation=="Ahmedabad")
		{
			billamount=8000;
		}
		if(flocation=="Bhopal" && tlocation=="Delhi")
		{
			billamount=4000;
		}
		if(flocation=="Bhopal" && tlocation=="Diu")
		{
			billamount=8000;
		}
		if(flocation=="Bhopal" && tlocation=="Gorakhpur")
		{
			billamount=7000;
		}
		if(flocation=="Bhopal" && tlocation=="Bengaluru")
		{
			billamount=8000;
		}
		if(flocation=="Bhuj" && tlocation=="Bengaluru")
		{
			billamount=9000;
		}
		if(flocation=="Bhuj" && tlocation=="Allahabad")
		{
			billamount=6000;
		}
		if(flocation=="Bhuj" && tlocation=="Bhopal")
		{
			billamount=7000;
		}
		if(flocation=="Bhuj" && tlocation=="Dehradun")
		{
			billamount=8000;
		}
		if(flocation=="Bhuj" && tlocation=="Ahmedabad")
		{
			billamount=9000;
		}
		if(flocation=="Bhuj" && tlocation=="Delhi")
		{
			billamount=4000;
		}
		if(flocation=="Bhuj" && tlocation=="Diu")
		{
			billamount=7000;
		}
		if(flocation=="Bhuj" && tlocation=="Gorakhpur")
		{
			billamount=8000;
		}
		if(flocation=="Dehradun" && tlocation=="Bengaluru")
		{
			billamount=5000;
		}
		if(flocation=="Dehradun" && tlocation=="Allahabad")
		{
			billamount=5000;
		}
		if(flocation=="Dehradun" && tlocation=="Bhopal")
		{
			billamount=7000;
		}
		if(flocation=="Dehradun" && tlocation=="Bhuj")
		{
			billamount=8000;
		}
		if(flocation=="Dehradun" && tlocation=="Ahmedabad")
		{
			billamount=6000;
		}
		if(flocation=="Dehradun" && tlocation=="Delhi")
		{
			billamount=3000;
		}
		if(flocation=="Dehradun" && tlocation=="Diu")
		{
			billamount=3000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Gorakhpur")
		{
			billamount=3000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Bengaluru")
		{
			billamount=7000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Allahabad")
		{
			billamount=8000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Bhopal")
		{
			billamount=9000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Bhuj")
		{
			billamount=10000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Dehradun")
		{
			billamount=3000;
		}
		if(flocation=="Ahmedabad" && tlocation=="Delhi")
		{
			billamount=5500;
		}
		if(flocation=="Ahmedabad" && tlocation=="Diu")
		{
			billamount=5400;
		}
		if(flocation=="Ahmedabad" && tlocation=="Gorakhpur")
		{
			billamount=5900;
		}
		if(flocation=="Delhi" && tlocation=="Bengaluru")
		{
			billamount=5400;
		}
		if(flocation=="Delhi" && tlocation=="Allahabad")
		{
			billamount=7800;
		}
		if(flocation=="Delhi" && tlocation=="Bhopal")
		{
			billamount=2500;
		}
		if(flocation=="Delhi" && tlocation=="Bhuj")
		{
			billamount=7000;
		}
		if(flocation=="Delhi" && tlocation=="Dehradun")
		{
			billamount=2000;
		}
		if(flocation=="Delhi" && tlocation=="Ahmedabad")
		{
			billamount=9000;
		}
		if(flocation=="Delhi" && tlocation=="Diu")
		{
			billamount=3500;
		}
		if(flocation=="Delhi" && tlocation=="Gorakhpur")
		{
			billamount=4000;
		}
		if(flocation=="Diu" && tlocation=="Bengaluru")
		{
			billamount=8000;
		}
		if(flocation=="Diu" && tlocation=="Allahabad")
		{
			billamount=4000;
		}
		if(flocation=="Diu" && tlocation=="Bhopal")
		{
			billamount=7000;
		}
		if(flocation=="Diu" && tlocation=="Bhuj")
		{
			billamount=5000;
		}
		if(flocation=="Diu" && tlocation=="Dehradun")
		{
			billamount=6000;
		}
		if(flocation=="Diu" && tlocation=="Ahmedabad")
		{
			billamount=7000;
		}
		if(flocation=="Diu" && tlocation=="Delhi")
		{
			billamount=8000;
		}
		if(flocation=="Diu" && tlocation=="Gorakhpur")
		{
			billamount=9000;
		}
		if(flocation=="Gorakhpur" && tlocation=="Bengaluru")
		{
			billamount=10000;
		}
		if(flocation=="Gorakhpur" && tlocation=="Allahabad")
		{
			billamount=5000;
		}
		if(flocation=="Gorakhpur" && tlocation=="Bhopal")
		{
			billamount=6000;
		}
		if(flocation=="Gorakhpur" && tlocation=="Bhuj")
		{
			billamount=8700;
		}
		if(flocation=="Gorakhpur" && tlocation=="Dehradun")
		{
			billamount=6700;
		}
		if(flocation=="Gorakhpur" && tlocation=="Ahmedabad")
		{
			billamount=6300;
		}
		if(flocation=="Gorakhpur" && tlocation=="Delhi")
		{
			billamount=4300;
		}
		if(flocation=="Gorakhpur" && tlocation=="Diu")
		{
			billamount=5000;
		}
		tripBean.setBillamount(billamount);
		String userRegistered = tripDAO.registerUser(tripBean);
        
		if (userRegistered.equals("SUCCESS")) {
            session.setAttribute("TripBean",tripBean);

request.getRequestDispatcher("/tripdisplay.jsp").forward(request, response);
} else {
request.getRequestDispatcher("/trip.jsp").forward(request, response);
}
        }
        catch (Exception e) {
            response.sendError(503, "PROBLEM IN DATABASE...");
        }
    }
}
