package com.controller;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.DAO.SearchDAO;
public class SearchController extends HttpServlet {
                        private static final long serialVersionUID = 1L;

                        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

                                                response.setContentType("text/html");
                                                PrintWriter out = response.getWriter();
                                                String date=request.getParameter("date2");
                                                java.util.Date uDate=null;
                                                SearchDAO dao=new SearchDAO();
                                                try {
                                                                        //Convert , String to Date    
                                                                        uDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                                                                        ArrayList user_list = (ArrayList)dao.getSearchDetails(uDate);
                                                                        request.setAttribute("user_list", user_list);
                                                                        RequestDispatcher view = request.getRequestDispatcher("/searchDetails.jsp");
                                                                        view.forward(request, response);
                                                

                        }catch(Exception e) {
                                                
                        }
}

}
