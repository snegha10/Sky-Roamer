package com.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.ScheduleDAO;
import com.bean.ScheduleBean;

public class ScheduleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public ScheduleController() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flightname = request.getParameter("hname");
		String timing= request.getParameter("timing");
		String flocation= request.getParameter("flocation");
		String tlocation=request.getParameter("tlocation");
		String b=request.getParameter("availableseats");
		int availableseats= Integer.parseInt(b);
		String tripdate=request.getParameter("tripdate");
		String pilotname=request.getParameter("pilotname");
		String a=request.getParameter("rating");
		double rating=Double.parseDouble(a);
		String journeyhours=request.getParameter("journeyhours");

		ScheduleBean scheduleBean = new ScheduleBean();
		scheduleBean.setHname(flightname);
		scheduleBean.setTiming(timing);
		scheduleBean.setFlocation(flocation);
		scheduleBean.setTlocation(tlocation);
		scheduleBean.setPilotname(pilotname);
		scheduleBean.setAvailableseats(availableseats);
		scheduleBean.setRating(rating);
		scheduleBean.setJourneyhours(journeyhours);
		scheduleBean.setTripdate(tripdate);
		ScheduleDAO scheduleDAO = new ScheduleDAO();

		 HttpSession session=request.getSession();
		String userRegistered = scheduleDAO.scheduleUser(scheduleBean);

		if (userRegistered.equals("SUCCESS")) {
            session.setAttribute("ScheduleBean",scheduleBean);

request.getRequestDispatcher("/sdisplay.jsp").forward(request, response);
} else {
request.getRequestDispatcher("/schedule.jsp").forward(request, response);
}
	}
}

































/*package register.controller;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import register.bean.RegisterBean;
import register.DAO.RegisterDAO;

public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;


                public RegisterController() {
                }

                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



                                String userName = request.getParameter("userid");
                                String password = request.getParameter("password");
                                String firstname=request.getParameter("firstname");
                                String lastname=request.getParameter("lastname");
                                String age=request.getParameter("age");
                                String gender=request.getParameter("gender");
                                String contact=request.getParameter("contact");

                                RegisterBean registerBean = new RegisterBean(); 
                                registerBean.setUserName(userName);
                                registerBean.setPassword(password);
                                registerBean.setAge(age);
                                registerBean.setGender(gender);
                                registerBean.setFirstname(firstname);
                                registerBean.setLastname(lastname);
                                registerBean.setContact(contact);

                                if(firstname.isEmpty() || lastname.isEmpty() || userName.isEmpty() || 
                        				password.isEmpty() || age.isEmpty() || contact.isEmpty() || gender.isEmpty())
                        		{
                        			RequestDispatcher req = request.getRequestDispatcher("login.jsp");
                        			req.include(request, response);
                        		}
                        		else
                        		{
                        			RequestDispatcher req = request.getRequestDispatcher("reg.jsp");
                        			req.forward(request, response);
                        		}


                                RegisterDAO registerDao = new RegisterDAO(); 
                                String userValidate = registerDao.authenticateUser(registerBean); 
                                if(userValidate.equals("SUCCESS")) 
                                {
                                                request.setAttribute("userName", userName); 
                                                request.getRequestDispatcher("/home.jsp").forward(request, response);
                                }
                                else
                                {
                                                request.setAttribute("errMessage", userValidate); 
                                                request.getRequestDispatcher("/reg.jsp").forward(request, response);
                                }*/

