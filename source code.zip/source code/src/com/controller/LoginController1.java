package com.controller;


import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import com.DAO.LoginDAO1;
import com.bean.LoginBean1;

public class LoginController1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

                public LoginController1() {
                }

                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

                                

                                String userName = request.getParameter("adminid");
                                String password = request.getParameter("password");
                                LoginBean1 loginBean1 = new LoginBean1(); 

                                loginBean1.setAdminid(userName); 
                                loginBean1.setPassword(password);
                                HttpSession session=request.getSession();
                                LoginDAO1 loginDao1 = new LoginDAO1(); 
                                String userValidate = loginDao1.authenticateUser(loginBean1); 
                                if(userValidate.equals("SUCCESS")) 
                                {
                                	session.setAttribute("LoginBean",loginBean1);
                               
                                request.getRequestDispatcher("/schedule.jsp").forward(request, response);
                            } else {
                                
                                request.getRequestDispatcher("/login1.jsp").forward(request, response);
                            }

                }

}
