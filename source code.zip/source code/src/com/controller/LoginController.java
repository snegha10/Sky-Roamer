package com.controller;


import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import com.DAO.LoginDAO;
import com.bean.LoginBean;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

                public LoginController() {
                }

                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

                                

                                String userName = request.getParameter("userid");
                                String password = request.getParameter("password");
                                LoginBean loginBean = new LoginBean(); 

                                loginBean.setUserid(userName); 
                                loginBean.setPassword(password);
                                HttpSession session=request.getSession();
                                LoginDAO loginDao = new LoginDAO(); 
                                String userValidate = loginDao.authenticateUser(loginBean); 
                                if(userValidate.equals("SUCCESS")) 
                                {
                                	session.setAttribute("LoginBean",loginBean);
                                
                                request.getRequestDispatcher("/navigate.jsp").forward(request, response);
                            } else {
                                request.getRequestDispatcher("/login.jsp").forward(request, response);
                            }

                }

}
