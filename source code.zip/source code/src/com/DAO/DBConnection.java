package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
public class DBConnection {
                public static Connection createConnection()
                {
                                Connection con = null;
                                try 
                                {
                                                try 
                                                {
                                                                Class.forName("com.mysql.jdbc.Driver"); 
                                                } 
                                                catch (ClassNotFoundException e)
                                                {
                                                                e.printStackTrace();
                                                } 
                                                con= DriverManager.
                    getConnection("jdbc:mysql://localhost:3306/sky","root","root");
                                              //  System.out.println("Printing connection object "+con);
                                } 
                                catch (Exception e) 
                                {
                                                e.printStackTrace();
                                                System.out.println("Error in Connection "+e);
                                }
                                return con; 
                }
}
