package com.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.ScheduleBean;

import com.DAO.DBConnection;

public class ScheduleDAO {

	public String scheduleUser(ScheduleBean scheduleBean)
	{
		String flightname = scheduleBean.getHname();
		String timing = scheduleBean.getTiming();
		String flocation=scheduleBean.getFlocation();
		String tlocation=scheduleBean.getTlocation();
		int availableseats=scheduleBean.getAvailableseats();
		String pilotname = scheduleBean.getPilotname();
		String tripdate = scheduleBean.getTripdate();
		double rating=scheduleBean.getRating();
		String journeyhours=scheduleBean.getJourneyhours();
		Connection con = null;
		PreparedStatement preparedStatement = null;

		try
		{
			con = DBConnection.createConnection();
			String query = "insert into scheduling(hname,timing,flocation,tlocation,availableseats,rating,pilotname,journeyhours,tripdate) values (?,?,?,?,?,?,?,?,?)"; //Insert user details into the table 'scheduling'
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, flightname);
			preparedStatement.setString(2, timing);
			preparedStatement.setString(3, flocation);
			preparedStatement.setString(4, tlocation);
			preparedStatement.setInt(5, scheduleBean.getAvailableseats());
			preparedStatement.setDouble(6, scheduleBean.getRating());
			preparedStatement.setString(7, pilotname);
			preparedStatement.setString(8, journeyhours);
			preparedStatement.setString(9, tripdate);
			
			

			int i= preparedStatement.executeUpdate();

			if (i!=0)  
				return "SUCCESS"; 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return "Oops.. Something went wrong there..!";  
	}
}


