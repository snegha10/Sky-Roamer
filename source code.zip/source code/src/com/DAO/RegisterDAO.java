package com.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.RegisterBean;

import com.DAO.DBConnection;

public class RegisterDAO {

	public String registerUser(RegisterBean registerBean)
	{
		String firstname = registerBean.getFirstname();
		String lastname = registerBean.getLastname();
		String age=registerBean.getAge();
		String gender=registerBean.getGender();
		long contact=registerBean.getContact();
		String userName = registerBean.getUserid();
		String password = registerBean.getPassword();
        String pno=registerBean.getPno();
        String vno=registerBean.getVno();
		Connection con = null;
		PreparedStatement preparedStatement = null;

		try
		{
			con = DBConnection.createConnection();
			String query = "insert into registration(firstname,lastname,age,gender,contact,userid,password,pno,vno) values (?,?,?,?,?,?,?,?,?)"; //Insert user details into the table 'registration'
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, firstname);
			preparedStatement.setString(2, lastname);
			preparedStatement.setString(3, registerBean.getAge());
			preparedStatement.setString(4, gender);
			preparedStatement.setLong(5, registerBean.getContact());
			preparedStatement.setString(6, userName);
			preparedStatement.setString(7, password);
			preparedStatement.setString(8, pno);
			preparedStatement.setString(9, vno);
			int i= preparedStatement.executeUpdate();

			if (i!=0)  
				return "SUCCESS"; 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return "Oops.. Something went wrong there..!";  
	}
}

