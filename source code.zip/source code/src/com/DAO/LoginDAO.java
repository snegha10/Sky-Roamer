package com.DAO;

import java.sql.*;

import com.DAO.DBConnection;
import com.bean.LoginBean;
public class LoginDAO {
                public String authenticateUser(LoginBean loginBean)
                {
                                String userName = loginBean.getUserid(); //Keeping user entered values in temporary variables.
                                String password = loginBean.getPassword();
                                Connection con = null;
                                Statement statement = null;
                                ResultSet resultSet = null;
                                String userNameDB = "";
                                String passwordDB = "";
                                try
                                {
                                                con = DBConnection.createConnection(); 
                                                statement = con.createStatement(); 
                                                resultSet = statement.executeQuery("select userid,password from registration where userid='"+userName+"'"); 
                                                while(resultSet.next()) 
                                                {
                                                                userNameDB = resultSet.getString("userid"); 
                                                                passwordDB = resultSet.getString("password");
                                                                if(userName.equals(userNameDB) && password.equals(passwordDB))
                                                                {
                                                                                return "SUCCESS"; 
                                                                }
                                                }
                                }
                                                catch(SQLException e)
                                                {
                                                                e.printStackTrace();
                                                }
                                                return "Invalid user credentials"; 
                                
                }
}
