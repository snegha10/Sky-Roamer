package com.DAO;

import java.sql.*;
import java.util.*;
public class SearchDAO {
                        
                        public int insertUserDetails(java.util.Date uDate) {
                                                int i=0;
                                                Connection con = null;
                                                PreparedStatement pstmt=null;
                                                ResultSet rs=null;
                                                String sql=null;
                                                java.sql.Date sDate=null;
                                                
                                                try {
                                                                        
                                                    con=DBConnection.createConnection();
                                                  //Convert , util.Date to sql.Date
                                                    sDate = new java.sql.Date(uDate.getTime());
                                                    
                                                    sql="insert into scheduling(tripdate) values ( ?)";
                                                                        pstmt=con.prepareStatement(sql);
                                                                  
                                                                        pstmt.setDate(1, sDate);
                                                                        i=pstmt.executeUpdate();

                                                }catch(Exception e) {
                                                                       
                        }
                                                return i;
                                                
}
                        public static ArrayList getSearchDetails(java.util.Date date) {
                        Connection conn = null;
    ArrayList user_list = new ArrayList();
    Statement st=null;
    ResultSet rs=null;
    ArrayList al = null;
    java.sql.Date sDate=null;
    try {
                         
        conn =DBConnection.createConnection(); 
       //Convert , util.Date to sql.Date
                            sDate = new java.sql.Date(date.getTime());
       
                            String query = "select * from scheduling where tripdate='" + sDate + "' ";
                           
        st = conn.createStatement();
        rs = st.executeQuery(query);
      
        while (rs.next()) {
            al = new ArrayList();
            al.add(rs.getString(1));
            al.add(rs.getTime(2));
            al.add(rs.getString(3));  
            al.add(rs.getString(4));
            al.add(rs.getDate(5));
            al.add(rs.getInt(6));
            al.add(rs.getDouble(7));
            al.add(rs.getString(8));
            al.add(rs.getInt(9));
            user_list.add(al);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }finally {
                        try {
                        rs.close();
                        st.close();
                        conn.close();
                        }catch(SQLException se) {
                                                se.getMessage();
                        }
    }
    return user_list;
}
                        
}
