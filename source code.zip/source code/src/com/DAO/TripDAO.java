package com.DAO;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;

import com.bean.TripBean;

import com.DAO.DBConnection;
	public class TripDAO 
	{

		public String registerUser(TripBean tripBean)
		{
			String firstname = tripBean.getFirstname();
			String lastname = tripBean.getLastname();
			String flocation=tripBean.getFlocation();
			String tlocation=tripBean.getTlocation();
			String flightname=tripBean.getFlightname();  
			String gender=tripBean.getGender();
			long contact=tripBean.getContact();
			String userName = tripBean.getUserid();
			String tripdate = tripBean.getTripdate();
            String age=tripBean.getAge();
			Connection con = null;
			PreparedStatement preparedStatement = null;

			try
			{
				con = DBConnection.createConnection();
				String query = "insert into trip(firstname,lastname,flightname,tripdate,flocation,tlocation,gender,contact,userid,age) values (?,?,?,?,?,?,?,?,?,?)"; //Insert user details into the table 'trip'
				preparedStatement = con.prepareStatement(query);
				preparedStatement.setString(1, firstname);
				preparedStatement.setString(2, lastname);
				preparedStatement.setString(3, flightname);
				preparedStatement.setString(4, tripdate);
				preparedStatement.setString(5, flocation);
				preparedStatement.setString(6, tlocation);
				preparedStatement.setString(7, gender);
				preparedStatement.setLong(8, tripBean.getContact());
				preparedStatement.setString(9, userName);
				preparedStatement.setString(10, age);
				int i= preparedStatement.executeUpdate();

				if (i!=0)  
					return "SUCCESS"; 
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}

			return "Oops.. Something went wrong there..!";  
		}
	}

