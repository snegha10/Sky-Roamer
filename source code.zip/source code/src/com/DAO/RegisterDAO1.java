package com.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.RegisterBean1;

import com.DAO.DBConnection;

public class RegisterDAO1 {

	public String registerUser(RegisterBean1 registerBean1)
	{
		String firstname = registerBean1.getFirstname();
		String lastname = registerBean1.getLastname();
		String age=registerBean1.getAge();
		String gender=registerBean1.getGender();
		long contact=registerBean1.getContact();
		String adminName = registerBean1.getAdminid();
		String password = registerBean1.getPassword();

		Connection con = null;
		PreparedStatement preparedStatement = null;

		try
		{
			con = DBConnection.createConnection();
			String query = "insert into admin1(firstname,lastname,age,gender,contact,adminid,password) values (?,?,?,?,?,?,?)"; //Insert user details into the table 'admin1'
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, firstname);
			preparedStatement.setString(2, lastname);
			preparedStatement.setString(3, registerBean1.getAge());
			preparedStatement.setString(4, gender);
			preparedStatement.setLong(5, registerBean1.getContact());
			preparedStatement.setString(6, adminName);
			preparedStatement.setString(7, password);

			int i= preparedStatement.executeUpdate();

			if (i!=0)  
				return "SUCCESS"; 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return "Oops.. Something went wrong there..!";  
	}
}
