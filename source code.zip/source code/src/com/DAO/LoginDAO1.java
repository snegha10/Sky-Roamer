package com.DAO;

import java.sql.*;

import com.bean.LoginBean1;

import com.DAO.DBConnection;
public class LoginDAO1 {
                public String authenticateUser(LoginBean1 loginBean1)
                {
                                String userName = loginBean1.getAdminid(); //Keeping user entered values in temporary variables.
                                String password = loginBean1.getPassword();
                                Connection con = null;
                                Statement statement = null;
                                ResultSet resultSet = null;
                                String userNameDB = "";
                                String passwordDB = "";
                                try
                                {
                                                con = DBConnection.createConnection(); 
                                                statement = con.createStatement(); 
                                                resultSet = statement.executeQuery("select adminid,password from admin1 where adminid='"+userName+"'"); 
                                                while(resultSet.next()) 
                                                {
                                                                userNameDB = resultSet.getString("adminid"); 
                                                                passwordDB = resultSet.getString("password");
                                                                if(userName.equals(userNameDB) && password.equals(passwordDB))
                                                                {
                                                                                return "SUCCESS"; 
                                                                }
                                                }
                                }
                                                catch(SQLException e)
                                                {
                                                                e.printStackTrace();
                                                }
                                                return "Invalid user credentials"; 
                                
                }
}
