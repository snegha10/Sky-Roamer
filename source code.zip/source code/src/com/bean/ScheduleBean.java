package com.bean;

public class ScheduleBean 
{
private String hname;
private String timing;
private String flocation;
private String tlocation;
private int availableseats;
private double rating;
private String pilotname;
private String journeyhours;
private String tripdate;
public String getHname() {
	return hname;
}
public void setHname(String hname) {
	this.hname = hname;
}
public String getTiming() {
	return timing;
}
public void setTiming(String timing) {
	this.timing = timing;
}
public String getFlocation() {
	return flocation;
}
public void setFlocation(String flocation) {
	this.flocation = flocation;
}
public String getTlocation() {
	return tlocation;
}
public void setTlocation(String tlocation) {
	this.tlocation = tlocation;
}
public int getAvailableseats() {
	return availableseats;
}
public void setAvailableseats(int availableseats) {
	this.availableseats = availableseats;
}

public double getRating() {
	return rating;
}
public void setRating(double rating) {
	this.rating = rating;
}
public String getPilotname() {
	return pilotname;
}
public void setPilotname(String pilotname) {
	this.pilotname = pilotname;
}
public String getJourneyhours() {
	return journeyhours;
}
public void setJourneyhours(String journeyhours) {
	this.journeyhours = journeyhours;
}
public String getTripdate() {
	return tripdate;
}
public void setTripdate(String tripdate) {
	this.tripdate = tripdate;
}

}
