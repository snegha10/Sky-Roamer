function validate() {
	var UserId = document.form.userid.value;
	var Password = document.form.password.value;
	var FirstName= document.form.firstname.value;
	var LastName= document.form.lastname.value;
	var Age= document.form.age.value;
	var Gender= document.form.gender.value;
	var ContactNumber= document.form.contact.value;
	var pno= document.form.pno.value;
	var vno= document.form.vno.value;
	var message="";
	var f=false;
	

	if (UserId==null || UserId == "") {
	       f=true;
	message+="--Enter userId\n";
	document.form.UserId.focus();
	}
	if (Password == null || Password == "") {
	alert("Password cannot be blank");
	f=true;
	message+="--Enter password\n";
	document.form.Password.focus();
	}

	if (LastName == null || LastName == "") {
	       //alert("Last Name cannot be blank");
	       f=true;
	       message+="--Enter Last Name\n";
	       document.form.LastName.focus();
	}
	if (FirstName == null || FirstName == "") {
	      // alert("First Name cannot be blank");
	       f=true;
	       message+="--Enter First Name\n";
	       document.form.FirstName.focus();
	}
	if (Age == null || Age == "") {
	       //alert("Age Name cannot be blank");
	       f=true;
	       message+="--Select Age\n";
	       document.form.FirstName.focus();
	}
	if (form.Gender.selectedIndex==0) {
	      // alert("Gendercannot be blank");
	       f=true;
	       message+="--Select Gender\n";
	       document.form.FirstName.focus();
	}
	if (ContactNumber == null || ContactNumber == "") {
	      // alert("ContatcNumber cannot be blank");
	       f=true;
	       message+="--Enter Contact Number\n";
	       document.form.FirstName.focus();
	}

	if (pno == null || pno == "") {
	      // alert("Phoneno cannot be blank");
	       f=true;
	       message+="--Enter Passport Number\n";
	       document.form.FirstName.focus();
	}

	if (vno == null || vno == "") {
	       //alert(" cannot be blank");
	       f=true;
	       message+="--Enter Visa Number\n";
	       document.form.FirstName.focus();
	}
	if(f)
	       {
	       alert(message);
	       return false;
	       }
	       return true;
	}